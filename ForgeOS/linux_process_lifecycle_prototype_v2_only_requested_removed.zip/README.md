# Linux Process Lifecycle Demonstration – Working UI Prototype

## Run
1. Open `index.html` in Chrome/Edge/Firefox.
2. Select any process lifecycle topic from the left.
3. Click **Run Demo**.
4. The terminal output animates line-by-line.
5. The process diagram, key functions, explanation and related C code update automatically.

## Important
This is a browser prototype. Browser JavaScript cannot directly execute your Ubuntu C `fork()/exec()/wait()` system calls, so the UI simulates the expected output and process flow.

To make it a real executable system later, connect this frontend to a Linux backend/API that compiles and runs the C program.
